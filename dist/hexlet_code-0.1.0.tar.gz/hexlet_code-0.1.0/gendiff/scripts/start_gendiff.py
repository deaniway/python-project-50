#!/usr/bin/env python

from gendiff.cli import main_arg

if __name__ == '__main__':
    main_arg()
